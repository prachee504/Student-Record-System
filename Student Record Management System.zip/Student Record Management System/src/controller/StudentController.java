/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import model.Student;

/**
 *
 * @author user
 */
public class StudentController {

    private List<Student> studentList;

    // Constructor
    public StudentController() {
        studentList = new ArrayList<>();
    }

    // ADD student
    public void addStudent(Student s) {
        studentList.add(s);
    }

    // GET list (for edit)
    public List<Student> getList() {
        return studentList;
    }

    // LOAD data into JTable
    public void loadTable(DefaultTableModel model) {

        model.setRowCount(0); // clear table first

        for (Student s : studentList) {
            Object[] row = {
                s.getName(),
                s.getAddress(),
                s.getPhone(),
                s.getGender(),
                s.getCast(),
                s.getAge()
            };
            model.addRow(row);
        }
    }
}
 

